# Hack-O-Week Week 11–12 — React Hooks & React Router

## Requirements covered
- useRef
- useMemo
- useCallback
- useContext
- Custom Hooks
- Routes
- Nested Routes
- Route Parameters
- Navigation

## Run
```bash
npm install
npm run dev
```

Open the URL printed by Vite.

## What to demonstrate
1. Home page — overview.
2. Hooks — demonstrate useRef, useMemo, useCallback and useContext.
3. Custom Hooks — demonstrate useCounter and useLocalStorage.
4. Courses — demonstrate routes and nested route `/courses/:id`.
5. Click course details — demonstrates `useParams()`.
6. Use Back to Courses — demonstrates `useNavigate()`.

## Viva points
- `useRef` persists a mutable value/DOM reference without triggering a render.
- `useMemo` caches a calculated value until dependencies change.
- `useCallback` caches a function reference until dependencies change.
- `useContext` reads shared context without prop drilling.
- A custom hook is a reusable function whose name starts with `use`.
- A route maps a URL path to a React element.
- Nested routes render through the parent's `<Outlet />`.
- Route parameters are dynamic URL segments such as `:id`.
- `useNavigate()` performs programmatic navigation.
- `Link`/`NavLink` provide client-side navigation without a full page reload.
