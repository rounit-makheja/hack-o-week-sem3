import React, {
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState
} from "react";
import {
  Link,
  NavLink,
  Navigate,
  Outlet,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams
} from "react-router-dom";

/* -------------------- useContext -------------------- */
const ThemeContext = React.createContext();

const courses = [
  { id: 1, name: "React Hooks", code: "WEB-301", description: "useRef, useMemo, useCallback and useContext." },
  { id: 2, name: "React Router", code: "WEB-302", description: "Routes, nested routes, params and navigation." },
  { id: 3, name: "Custom Hooks", code: "WEB-303", description: "Reusable stateful logic with custom hooks." }
];

/* -------------------- Custom Hooks -------------------- */
function useDocumentTitle(title) {
  useEffect(() => {
    document.title = title;
    return () => {
      document.title = "Hack-O-Week React";
    };
  }, [title]);
}

function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);

  return [value, setValue];
}

function useCounter(initial = 0) {
  const [count, setCount] = useState(initial);
  const increment = () => setCount((c) => c + 1);
  const decrement = () => setCount((c) => c - 1);
  const reset = () => setCount(initial);
  return { count, increment, decrement, reset };
}

/* -------------------- Layout / Navigation -------------------- */
function Layout() {
  const location = useLocation();

  return (
    <div className="app">
      <header className="header">
        <div>
          <h1>React Week 11–12</h1>
          <p>Hooks • Custom Hooks • React Router</p>
        </div>
        <nav>
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/hooks">Hooks</NavLink>
          <NavLink to="/custom-hooks">Custom Hooks</NavLink>
          <NavLink to="/courses">Courses</NavLink>
          <NavLink to="/about">About</NavLink>
        </nav>
      </header>

      <main>
        <div className="route-info">
          Current route: <code>{location.pathname}</code>
        </div>
        <Outlet />
      </main>

      <footer>Hack-O-Week Practical • React Hooks & React Router</footer>
    </div>
  );
}

/* -------------------- Home -------------------- */
function Home() {
  useDocumentTitle("Home | React Hack-O-Week");

  return (
    <section className="card">
      <span className="badge">Completed Task</span>
      <h2>React Hooks & React Router</h2>
      <p>
        This project demonstrates the concepts listed in the Week 11 and 12
        Hack-O-Week plan using working React components.
      </p>

      <div className="grid">
        <Link className="tile" to="/hooks">Explore React Hooks →</Link>
        <Link className="tile" to="/custom-hooks">Explore Custom Hooks →</Link>
        <Link className="tile" to="/courses">Explore Router Demo →</Link>
      </div>
    </section>
  );
}

/* -------------------- Hooks Demo -------------------- */
function HooksDemo() {
  useDocumentTitle("Hooks Demo | React Hack-O-Week");

  const inputRef = useRef(null);
  const renderCount = useRef(0);
  const [search, setSearch] = useState("");
  const [theme, setTheme] = useState("dark");

  renderCount.current += 1;

  const filteredCourses = useMemo(() => {
    const q = search.toLowerCase().trim();
    return courses.filter(
      (course) =>
        !q ||
        course.name.toLowerCase().includes(q) ||
        course.code.toLowerCase().includes(q)
    );
  }, [search]);

  const focusInput = useCallback(() => {
    inputRef.current?.focus();
  }, []);

  const themeValue = useMemo(
    () => ({ theme, toggleTheme: () => setTheme((t) => t === "dark" ? "light" : "dark") }),
    [theme]
  );

  return (
    <ThemeContext.Provider value={themeValue}>
      <section className={`card ${theme}`}>
        <h2>React Hooks Demonstration</h2>

        <div className="demo">
          <h3>1. useRef</h3>
          <p>Stores a DOM reference without causing a re-render.</p>
          <input ref={inputRef} placeholder="Click the button to focus me" />
          <button onClick={focusInput}>Focus Input</button>
          <p>Render count stored in useRef: <strong>{renderCount.current}</strong></p>
        </div>

        <div className="demo">
          <h3>2. useMemo</h3>
          <p>Memoizes an expensive calculation until its dependencies change.</p>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter courses..."
          />
          <ul>
            {filteredCourses.map((course) => (
              <li key={course.id}>{course.name} — {course.code}</li>
            ))}
          </ul>
        </div>

        <div className="demo">
          <h3>3. useCallback</h3>
          <p>Memoizes a function reference so child components can avoid unnecessary work.</p>
          <button onClick={focusInput}>Run memoized focus callback</button>
        </div>

        <div className="demo">
          <h3>4. useContext</h3>
          <ThemeConsumer />
        </div>
      </section>
    </ThemeContext.Provider>
  );
}

function ThemeConsumer() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  return (
    <div>
      <p>Context value received by child: <strong>{theme}</strong></p>
      <button onClick={toggleTheme}>Toggle Theme Through Context</button>
    </div>
  );
}

/* -------------------- Custom Hooks Demo -------------------- */
function CustomHooksDemo() {
  useDocumentTitle("Custom Hooks | React Hack-O-Week");

  const { count, increment, decrement, reset } = useCounter(10);
  const [name, setName] = useLocalStorage("hack-o-week-name", "");

  return (
    <section className="card">
      <h2>Custom Hooks</h2>
      <p>
        Custom hooks extract reusable stateful logic. Their names conventionally
        start with <code>use</code>.
      </p>

      <div className="demo">
        <h3>Custom Hook 1: useCounter()</h3>
        <p>Count: <strong>{count}</strong></p>
        <button onClick={decrement}>−</button>
        <button onClick={reset}>Reset</button>
        <button onClick={increment}>+</button>
      </div>

      <div className="demo">
        <h3>Custom Hook 2: useLocalStorage()</h3>
        <p>This value survives a page refresh.</p>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
        />
        <p>Hello, <strong>{name || "Student"}</strong>!</p>
      </div>

      <div className="note">
        <strong>Rule:</strong> Custom hooks can call other hooks, but they must
        be called at the top level of a React component or another custom hook.
      </div>
    </section>
  );
}

/* -------------------- Router Demo -------------------- */
function Courses() {
  useDocumentTitle("Courses | React Hack-O-Week");

  return (
    <section className="card">
      <h2>React Router Demo</h2>
      <p>These are route links using React Router.</p>
      <div className="course-list">
        {courses.map((course) => (
          <div className="course" key={course.id}>
            <div>
              <strong>{course.name}</strong>
              <p>{course.description}</p>
            </div>
            <Link to={`/courses/${course.id}`}>View Details</Link>
          </div>
        ))}
      </div>
      <Outlet />
    </section>
  );
}

function CourseDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const course = courses.find((c) => String(c.id) === id);

  if (!course) return <Navigate to="/not-found" replace />;

  return (
    <div className="demo">
      <h3>Route Parameter Demo</h3>
      <p><strong>ID from URL:</strong> {id}</p>
      <p><strong>Course:</strong> {course.name}</p>
      <p><strong>Code:</strong> {course.code}</p>
      <button onClick={() => navigate("/courses")}>Back to Courses</button>
    </div>
  );
}

function About() {
  useDocumentTitle("About | React Hack-O-Week");
  return (
    <section className="card">
      <h2>About This Practical</h2>
      <p>
        Built to cover Week 11 and 12 requirements: React Hooks, Custom Hooks,
        routes, nested routes, route parameters and navigation.
      </p>
    </section>
  );
}

function NotFound() {
  return (
    <section className="card">
      <h2>404 — Page Not Found</h2>
      <Link to="/">Return Home</Link>
    </section>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="hooks" element={<HooksDemo />} />
        <Route path="custom-hooks" element={<CustomHooksDemo />} />
        <Route path="courses" element={<Courses />}>
          <Route path=":id" element={<CourseDetails />} />
        </Route>
        <Route path="about" element={<About />} />
        <Route path="not-found" element={<NotFound />} />
        <Route path="*" element={<Navigate to="/not-found" replace />} />
      </Route>
    </Routes>
  );
}