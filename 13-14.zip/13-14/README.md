# Hack-O-Week Weeks 13–14 — React

## Completed syllabus
1. Context API for state sharing
2. Prop Drilling vs Context API
3. Basic state management patterns
4. CSS Modules
5. Tailwind CSS
6. styled-components
7. Practical comparison table
8. Viva checklist

## Run
```bash
npm install
npm run dev
```

## Practical demonstration
- Prop Drilling section shows data passed Level 1 → Level 2 → Level 3.
- Context API section shows the same kind of shared data consumed directly by a deep child.
- State section demonstrates scalar state, shared state and array state.
- Styling section explains the three requested approaches and provides a theme toggle.
- Comparison table summarizes when each approach is appropriate.

## Important theory
### Prop drilling
Passing props through intermediate components only so a deeply nested component can use them.

### Context API
React's built-in mechanism for providing values to descendants without explicitly passing props through every intermediate component.

### State management
State represents data that can change over time and trigger React re-renders. `useState` is appropriate for local component state; Context can expose shared state to many descendants.

### CSS Modules
CSS files whose class names are scoped to the component/module.

### Tailwind CSS
A utility-first CSS framework where UI is composed from small utility classes.

### styled-components
A CSS-in-JS library that creates styled React components using JavaScript template literals.

## Suggested viva answer
Use props when the data relationship is simple and explicit. Use Context when many descendants need the same value, such as theme, locale or authenticated user information. Context is not automatically a replacement for every state-management library.
