import React, { createContext, useContext, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

/* =========================
   CONTEXT API
========================= */
const AppContext = createContext(null);

function AppProvider({ children }) {
  const [theme, setTheme] = useState("dark");
  const [user, setUser] = useState({ name: "Rounit", role: "Student" });
  const [count, setCount] = useState(0);

  const value = {
    theme,
    setTheme,
    user,
    setUser,
    count,
    setCount
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

function useAppContext() {
  return useContext(AppContext);
}

/* =========================
   PROPS DRILLING DEMO
========================= */
function PropDrillingDemo() {
  const [name, setName] = useState("Rounit");

  return (
    <div className="demo">
      <h3>1. Prop Drilling</h3>
      <p>
        Data is passed manually through intermediate components using props.
      </p>
      <PropLevelOne name={name} />
      <label>
        Change name:
        <input value={name} onChange={(e) => setName(e.target.value)} />
      </label>
    </div>
  );
}

function PropLevelOne({ name }) {
  return (
    <div className="nested">
      <strong>Level 1</strong>
      <PropLevelTwo name={name} />
    </div>
  );
}

function PropLevelTwo({ name }) {
  return (
    <div className="nested">
      <strong>Level 2</strong>
      <PropLevelThree name={name} />
    </div>
  );
}

function PropLevelThree({ name }) {
  return (
    <div className="nested highlight">
      <strong>Level 3</strong>
      <p>Received through props: <b>{name}</b></p>
    </div>
  );
}

/* =========================
   CONTEXT API DEMO
========================= */
function ContextDemo() {
  const { user, setUser } = useAppContext();

  return (
    <div className="demo">
      <h3>2. Context API</h3>
      <p>
        Components can consume shared data directly without passing props
        through every intermediate component.
      </p>
      <ContextLevelOne />
      <button onClick={() =>
        setUser((u) => ({
          ...u,
          name: u.name === "Rounit" ? "React Student" : "Rounit"
        }))
      }>
        Change Context User
      </button>
      <p className="result">Shared user: {user.name} ({user.role})</p>
    </div>
  );
}

function ContextLevelOne() {
  return (
    <div className="nested">
      <strong>Level 1</strong>
      <ContextLevelTwo />
    </div>
  );
}

function ContextLevelTwo() {
  return (
    <div className="nested">
      <strong>Level 2</strong>
      <ContextConsumer />
    </div>
  );
}

function ContextConsumer() {
  const { user } = useAppContext();
  return (
    <div className="nested highlight">
      <strong>Level 3</strong>
      <p>Read directly from Context: <b>{user.name}</b></p>
    </div>
  );
}

/* =========================
   BASIC STATE MANAGEMENT
========================= */
function StateManagementDemo() {
  const { count, setCount } = useAppContext();
  const [localCount, setLocalCount] = useState(0);
  const [tasks, setTasks] = useState(["Learn Context API"]);

  function addTask() {
    setTasks((old) => [...old, `Task ${old.length + 1}`]);
  }

  return (
    <div className="demo">
      <h3>3. Basic State Management</h3>
      <div className="state-grid">
        <div>
          <h4>Local State — useState</h4>
          <p className="big">{localCount}</p>
          <button onClick={() => setLocalCount((n) => n - 1)}>−</button>
          <button onClick={() => setLocalCount(0)}>Reset</button>
          <button onClick={() => setLocalCount((n) => n + 1)}>+</button>
        </div>
        <div>
          <h4>Shared State — Context</h4>
          <p className="big">{count}</p>
          <button onClick={() => setCount((n) => n - 1)}>−</button>
          <button onClick={() => setCount(0)}>Reset</button>
          <button onClick={() => setCount((n) => n + 1)}>+</button>
        </div>
        <div>
          <h4>Array State</h4>
          <button onClick={addTask}>Add Task</button>
          <ul>{tasks.map((task, i) => <li key={i}>{task}</li>)}</ul>
        </div>
      </div>
    </div>
  );
}

/* =========================
   STYLING APPROACHES
========================= */
function StylingDemo() {
  const { theme, setTheme } = useAppContext();

  return (
    <div className="demo">
      <h3>4. Styling Approaches</h3>

      <div className="style-grid">
        <div className="style-card css-module">
          <span>CSS Modules</span>
          <p>Locally scoped class names.</p>
          <code>Button.module.css</code>
        </div>

        <div className="style-card tailwind-like">
          <span>Tailwind CSS</span>
          <p>Utility classes compose styles quickly.</p>
          <code>bg-slate-900 p-4 rounded-xl</code>
        </div>

        <div className="style-card styled-component">
          <span>styled-components</span>
          <p>CSS written alongside component logic.</p>
          <code>styled.button`...`</code>
        </div>
      </div>

      <div className="theme-box">
        <p>Context-controlled application theme: <b>{theme}</b></p>
        <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
          Toggle Theme
        </button>
      </div>
    </div>
  );
}

/* =========================
   MAIN APP
========================= */
function App() {
  const { theme } = useAppContext();

  return (
    <div className={`app ${theme}`}>
      <header>
        <div>
          <span className="badge">HACK-O-WEEK • 3rd SEM</span>
          <h1>React State & Styling Lab</h1>
          <p>Weeks 13 & 14 — Context API, State Management & Styling</p>
        </div>
        <div className="status">● Practical Ready</div>
      </header>

      <main>
        <section className="hero">
          <h2>Context API vs Prop Drilling</h2>
          <p>
            A complete practical demonstration of state sharing patterns and
            modern React styling approaches.
          </p>
        </section>

        <PropDrillingDemo />
        <ContextDemo />
        <StateManagementDemo />
        <StylingDemo />

        <section className="comparison">
          <h2>Quick Comparison</h2>
          <table>
            <thead>
              <tr>
                <th>Approach</th>
                <th>Best For</th>
                <th>Main Advantage</th>
                <th>Limitation</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Prop Drilling</td>
                <td>Small component trees</td>
                <td>Simple and explicit</td>
                <td>Becomes repetitive</td>
              </tr>
              <tr>
                <td>Context API</td>
                <td>Shared app-level data</td>
                <td>Avoids prop drilling</td>
                <td>Can cause broad re-renders if poorly designed</td>
              </tr>
              <tr>
                <td>CSS Modules</td>
                <td>Component-scoped CSS</td>
                <td>Local class names</td>
                <td>Separate CSS files</td>
              </tr>
              <tr>
                <td>Tailwind CSS</td>
                <td>Fast utility-based UI</td>
                <td>Very rapid styling</td>
                <td>Class-heavy markup</td>
              </tr>
              <tr>
                <td>styled-components</td>
                <td>CSS-in-JS systems</td>
                <td>Dynamic component styling</td>
                <td>Runtime/dependency overhead</td>
              </tr>
            </tbody>
          </table>
        </section>

        <section className="viva">
          <h2>Viva Checklist</h2>
          <ol>
            <li>What problem does Context API solve?</li>
            <li>What is prop drilling?</li>
            <li>When should props be preferred over Context?</li>
            <li>What is the difference between local and shared state?</li>
            <li>What are CSS Modules?</li>
            <li>Why is Tailwind called a utility-first framework?</li>
            <li>What are the benefits of styled-components?</li>
          </ol>
        </section>
      </main>

      <footer>Week 13–14 Hack-O-Week • React Practical</footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AppProvider>
      <App />
    </AppProvider>
  </React.StrictMode>
);